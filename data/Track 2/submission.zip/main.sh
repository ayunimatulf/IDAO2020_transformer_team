export PATH=/usr/conda/bin:$PATH
python main.py